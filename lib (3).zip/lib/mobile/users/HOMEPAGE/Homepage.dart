import 'package:flutter/material.dart';
import 'package:flutter_application_ecommers/mobile/users/HOMEPAGE/costumer1.dart';
import 'package:flutter_application_ecommers/splash.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    final searchController = TextEditingController();

    return SafeArea(
      child: Scaffold(
        body: Container(
          height: height,
          width: width,
          color: Colors.grey[200],
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: height * 0.1,
                  width: width,
                  // color: Colors.blue,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color: Colors.black,
                            size: 30,
                          )),
                      Text(
                        'Search',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            letterSpacing: 0.5),
                      ),
                      Icon(
                        Icons.more_vert_outlined,
                        color: Colors.black,
                        size: 30,
                      ),
                    ],
                  ),
                ),
                Container(
                  height: height * 0.27,
                  width: width,
                  // color: Colors.yellow,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        height: height * 0.08,
                        width: width,
                        // color: Colors.purple,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Container(
                              height: height * 0.06,
                              width: width * 0.8,
                              child: TextFormField(
                                decoration: InputDecoration(
                                    enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)),
                                        borderSide: BorderSide(
                                            color: Colors.grey[400]!)),
                                    focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)),
                                        borderSide: BorderSide(
                                            color: Colors.grey[400]!)),
                                    filled: true,
                                    prefixIcon: Icon(
                                      Icons.search,
                                      color: Colors.grey,
                                    ),
                                    fillColor: Colors.white,
                                    hintText: "Women in Construction",
                                    hintStyle: TextStyle(fontSize: 13)),
                                controller: searchController,
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              height: height * 0.06,
                              width: width * 0.11,
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Icon(
                                Icons.filter_list,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: height * 0.08,
                        width: width,
                        // color: Colors.red,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Container(
                              alignment: Alignment.center,
                              height: height * 0.06,
                              width: width * 0.3,
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Text(
                                "Plumber",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13),
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              height: height * 0.06,
                              width: width * 0.3,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Text(
                                "Electrician",
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13),
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              height: height * 0.06,
                              width: width * 0.3,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Text(
                                "Carpenter",
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: height * 0.06,
                        width: width,
                        // color: Colors.orange,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                "Results",
                                style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold),
                              ),
                              Container(
                                height: height * 0.07,
                                width: width * 0.15,
                                // color: Colors.red,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    Icon(
                                      Icons.window,
                                      color: Colors.black,
                                      size: 20,
                                    ),
                                    Icon(
                                      Icons.menu_sharp,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: PageView(
                    children: [
                      Container(
                          width: width,
                          // color: Colors.green,
                          child: ListView(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Container(
                                      height: height * 0.4,
                                      width: width,
                                      // color: Colors.red,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        Emily(),
                                                  ));
                                            },
                                            child: Container(
                                              height: height * 0.4,
                                              width: width * 0.43,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15)),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Container(
                                                      height: height * 0.22,
                                                      width: width * 0.45,
                                                      decoration: BoxDecoration(
                                                          // color: Colors.pink,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(15),
                                                          image: DecorationImage(
                                                              image: AssetImage(
                                                                  "assets/images/pic1.jpeg"),
                                                              fit: BoxFit
                                                                  .cover)),
                                                    ),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          "EMILY JOHNSON",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.black,
                                                              // fontWeight:
                                                              //     FontWeight.bold,
                                                              fontSize: 14),
                                                        ),
                                                      ],
                                                    ),
                                                    Text(
                                                      "Emergency Plumbing Services",
                                                      style: TextStyle(
                                                          color:
                                                              Colors.grey[700],
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 13),
                                                    ),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Text(
                                                          "5 reviews",
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .grey[700],
                                                              fontSize: 13),
                                                        ),
                                                        Text(
                                                          "&250",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: 20),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      children: [
                                                        Icon(
                                                          Icons.star,
                                                          size: 18,
                                                          color: Color.fromARGB(
                                                              255, 255, 193, 7),
                                                        ),
                                                        Icon(
                                                          Icons.star,
                                                          size: 18,
                                                          color: Color.fromARGB(
                                                              255, 255, 193, 7),
                                                        ),
                                                        Icon(
                                                          Icons.star,
                                                          size: 18,
                                                          color: Color.fromARGB(
                                                              255, 255, 193, 7),
                                                        ),
                                                        Icon(
                                                          Icons.star,
                                                          size: 18,
                                                          color: Color.fromARGB(
                                                              255, 255, 193, 7),
                                                        ),
                                                        Icon(
                                                          Icons.star,
                                                          size: 18,
                                                          color: Color.fromARGB(
                                                              255, 255, 193, 7),
                                                        )
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            height: height * 0.4,
                                            width: width * 0.43,
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Container(
                                                    height: height * 0.22,
                                                    width: width * 0.45,
                                                    decoration: BoxDecoration(
                                                        // color: Colors.pink,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(15),
                                                        image: DecorationImage(
                                                            image: AssetImage(
                                                                "assets/images/pic2.jpeg"),
                                                            fit: BoxFit.cover)),
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Text(
                                                        "EMILY JOHNSON",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            // fontWeight:
                                                            //     FontWeight.bold,
                                                            fontSize: 14),
                                                      ),
                                                    ],
                                                  ),
                                                  Text(
                                                    "Emergency Plumbing Services",
                                                    style: TextStyle(
                                                        color: Colors.grey[700],
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 13),
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Text(
                                                        "5 reviews",
                                                        style: TextStyle(
                                                            color: Colors
                                                                .grey[700],
                                                            fontSize: 13),
                                                      ),
                                                      Text(
                                                        "&250",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 20),
                                                      ),
                                                    ],
                                                  ),
                                                  Row(
                                                    children: [
                                                      Icon(
                                                        Icons.star,
                                                        size: 18,
                                                        color: Color.fromARGB(
                                                            255, 255, 193, 7),
                                                      ),
                                                      Icon(
                                                        Icons.star,
                                                        size: 18,
                                                        color: Color.fromARGB(
                                                            255, 255, 193, 7),
                                                      ),
                                                      Icon(
                                                        Icons.star,
                                                        size: 18,
                                                        color: Color.fromARGB(
                                                            255, 255, 193, 7),
                                                      ),
                                                      Icon(
                                                        Icons.star,
                                                        size: 18,
                                                        color: Color.fromARGB(
                                                            255, 255, 193, 7),
                                                      ),
                                                      Icon(
                                                        Icons.star,
                                                        size: 18,
                                                        color: Color.fromARGB(
                                                            255, 255, 193, 7),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),

                                          //////replace later
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: height * 0.02,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          height: height * 0.4,
                                          width: width * 0.43,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(15)),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Container(
                                                  height: height * 0.22,
                                                  width: width * 0.45,
                                                  decoration: BoxDecoration(
                                                      // color: Colors.pink,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              "assets/images/pic3.jpeg"),
                                                          fit: BoxFit.cover)),
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      "EMILY JOHNSON",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          // fontWeight:
                                                          //     FontWeight.bold,
                                                          fontSize: 14),
                                                    ),
                                                  ],
                                                ),
                                                Text(
                                                  "Emergency Plumbing Services",
                                                  style: TextStyle(
                                                      color: Colors.grey[700],
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 13),
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      "5 reviews",
                                                      style: TextStyle(
                                                          color:
                                                              Colors.grey[700],
                                                          fontSize: 13),
                                                    ),
                                                    Text(
                                                      "&250",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 20),
                                                    ),
                                                  ],
                                                ),
                                                Row(
                                                  children: [
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: height * 0.4,
                                          width: width * 0.43,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(15)),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Container(
                                                  height: height * 0.22,
                                                  width: width * 0.45,
                                                  decoration: BoxDecoration(
                                                      // color: Colors.pink,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              "assets/images/pic4.jpeg"),
                                                          fit: BoxFit.cover)),
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      "EMILY JOHNSON",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          // fontWeight:
                                                          //     FontWeight.bold,
                                                          fontSize: 14),
                                                    ),
                                                  ],
                                                ),
                                                Text(
                                                  "Emergency Plumbing Services",
                                                  style: TextStyle(
                                                      color: Colors.grey[700],
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 13),
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      "5 reviews",
                                                      style: TextStyle(
                                                          color:
                                                              Colors.grey[700],
                                                          fontSize: 13),
                                                    ),
                                                    Text(
                                                      "&250",
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 20),
                                                    ),
                                                  ],
                                                ),
                                                Row(
                                                  children: [
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    ),
                                                    Icon(
                                                      Icons.star,
                                                      size: 18,
                                                      color: Color.fromARGB(
                                                          255, 255, 193, 7),
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        ), //////replace later
                                      ],
                                    ),
                                  ],
                                ),
                              )
                            ],
                          )),
                      Container(
                        width: width,
                        color: Colors.red,
                      ),
                      Container(
                        width: width,
                        color: Colors.blue,
                      ),
                    ],
                    controller: PageController(),
                  ),
                ),
                Container(
                  height: height * 0.1,
                  width: width,
                  color: Colors.white,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Icon(
                        Icons.home,
                        color: Colors.grey,
                      ),
                      Icon(
                        Icons.search,
                        color: Colors.grey,
                      ),
                      Icon(
                        Icons.chat,
                        color: Colors.grey,
                      ),
                      Icon(
                        Icons.person,
                        color: Colors.grey,
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
