import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_ecommers/mobile/users/HOMEPAGE/chat_screen.dart';
import 'package:flutter_application_ecommers/mobile/users/HOMEPAGE/requestScreen.dart';
import 'package:flutter_application_ecommers/mobile/users/UserModel.dart';
import 'package:flutter_application_ecommers/mobile/users/staticdata.dart';
import 'package:flutter_application_ecommers/models/FriendModel.dart';
import 'package:flutter_application_ecommers/models/reqModel.dart';

import 'package:uuid/uuid.dart';

class Dashboard1 extends StatefulWidget {
  const Dashboard1({super.key});

  @override
  State<Dashboard1> createState() => _Dashboard1State();
}

class _Dashboard1State extends State<Dashboard1> {
  PageController controller = PageController();
  // height = MediaQuery.of(context).size.height;
  // width = MediaQuery.of(context).size.width;
  final Firstnamecontroller = TextEditingController();
  final Lastnamecontroller = TextEditingController();
  final emailcontroller = TextEditingController();
  final passwordcontroller = TextEditingController();
  final updatecontroller = TextEditingController();
  final mailupdatecontroller = TextEditingController();
  final datecontroller = TextEditingController();
  final numbercontroller = TextEditingController();

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  List<UserModel> allUsers = [];
  void getUsers() async {
    allUsers.clear();
    QuerySnapshot snapshot =
        await FirebaseFirestore.instance.collection("users").get();

    for (var data in snapshot.docs) {
      UserModel model = UserModel.fromMap(data.data() as Map<String, dynamic>);
      setState(() {
        allUsers.add(model);
      });
    }
  }

  List<FriendModel> allfiends = [];
  void getfriend() async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection("Friends")
        .where("userId", isEqualTo: StaticData.model!.userId)
        .get();

    for (var data in snapshot.docs) {
      FriendModel model =
          FriendModel.fromMap(data.data() as Map<String, dynamic>);
      setState(() {
        allfiends.add(model);
      });
    }
  }

  @override
  void initState() {
    getUsers();
    getfriend();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    void initState() {
      getUsers();
      getfriend();

      super.initState();
    }

    String chatRoomId(String user1, String user2) {
      ////////chat room
      if (user1[0].toLowerCase().codeUnits[0] >
          user2.toLowerCase().codeUnits[0]) {
        return "$user1$user2";
      } else {
        return "$user2$user1";
      }
    }

    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
        // key: _scaffoldKey,
        // drawer: Drawer(
        //     child: Stack(
        //   children: [
        //     Container(
        //       height: height,
        //       width: width,
        //       color: Color.fromRGBO(0, 150, 136, 1),
        //       child: Padding(
        //         padding: EdgeInsets.only(top: height * 0.15),
        //         child: Container(
        //           height: height! * 0.4,
        //           width: width,
        //           decoration: BoxDecoration(
        //               color: Colors.white,
        //               borderRadius: BorderRadius.only(
        //                   topRight: Radius.circular(30),
        //                   topLeft: Radius.circular(30))),
        //           child: Column(
        //             children: [
        //               SizedBox(
        //                 height: 24,
        //               ),
        //               Container(
        //                 height: height! * 0.08,
        //                 width: width,
        //                 color: Colors.green,
        //               ),
        //               SizedBox(
        //                 height: 12,
        //               ),
        //               Container(
        //                 height: height! * 0.08,
        //                 width: width,
        //                 color: Colors.yellow,
        //               ),
        //               SizedBox(
        //                 height: 12,
        //               ),
        //               Container(
        //                 height: height! * 0.08,
        //                 width: width,
        //                 color: Colors.teal,
        //               ),
        //             ],
        //           ),
        //         ),
        //       ),
        //     ),
        //   ],
        // )),
        body: Column(
          children: [
            Expanded(
              child: PageView(
                controller: controller,
                scrollDirection: Axis.horizontal,
                children: [
                  Container(
                    height: height,
                    width: width,
                    color: Colors.white,
                    child: Expanded(
                      child: Container(
                        width: width,
                        decoration: BoxDecoration(
                          color: Colors.black,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              height: height * 0.22,
                              width: width,
                              color: Colors.black,
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Container(
                                    height: height * 0.1,
                                    width: width * 0.9,
                                    // color: Colors.pink,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          height: height * 0.1,
                                          width: width * 0.2,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              shape: BoxShape.circle,
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/images/pic6.png"),
                                                  fit: BoxFit.cover)),
                                        ),
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          height: height * 0.07,
                                          width: width * 0.53,
                                          color: Colors.black,
                                          child: Text(
                                            "Hello,Alexandero!",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 17,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        Icon(
                                          Icons.menu,
                                          size: 25,
                                          color: Colors.white,
                                        )
                                      ],
                                    ),
                                  ),
                                  Container(
                                    height: height * 0.07,
                                    width: width * 0.8,
                                    child: TextFormField(
                                      decoration: InputDecoration(
                                          enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(30)),
                                              borderSide: BorderSide(
                                                  color: Colors.white)),
                                          focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(30)),
                                              borderSide: BorderSide(
                                                  color: Colors.white)),
                                          filled: true,
                                          fillColor: Colors.grey[100],
                                          hintText: "Search",
                                          prefixIcon: Icon(Icons.search),
                                          hintStyle:
                                              TextStyle(color: Colors.black)),
                                      controller: passwordcontroller,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              height: height * 0.64,
                              width: width,
                              color: Colors.black,
                              child: ListView.builder(
                                  //////////////chatroom
                                  itemCount: allfiends.length,
                                  itemBuilder: (context, index) {
                                    return Stack(children: [
                                      InkWell(
                                        onTap: () {
                                          String chatid = chatRoomId(
                                              StaticData.model!.userId!,
                                              allfiends[index].friendId!);
                                          print(chatid);
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    ChatScreen(
                                                  chatroomId: chatid,
                                                  userModel: allfiends[index],
                                                  profileModel:
                                                      StaticData.model!,
                                                  username: allfiends[index]
                                                      .friendname!,
                                                  status: 'online',
                                                ),
                                              ));
                                        },
                                        child: Center(
                                          child: Container(
                                              alignment: Alignment.centerLeft,
                                              height: height * 0.12,
                                              width: width * 0.9,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15)),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    alignment: Alignment.center,
                                                    height: height * 0.08,
                                                    width: width * 0.15,
                                                    decoration: BoxDecoration(
                                                        color: Colors.blue,
                                                        shape: BoxShape.circle),
                                                    child: Icon(
                                                      Icons.person,
                                                      size: 35,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                  Container(
                                                    height: height * 0.08,
                                                    width: width * 0.5,
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              8.0),
                                                      child: Text(
                                                        allfiends[index]
                                                            .friendname!,
                                                        style: TextStyle(
                                                            fontSize: 20,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )),
                                        ),
                                      ),
                                    ]);
                                  }),
                            ),
                            //////////////////
                          ],
                        ),
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      Container(
                alignment: Alignment.center,
                height: height * 0.1,
                width: width,
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.arrow_back,
                          size: 30,
                        )),
                    Container(
                      alignment: Alignment.centerLeft,
                      height: height * 0.09,
                      width: width * 0.85,
                      child: Text(
                        "All Users",
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 24),
                      ),
                    ),
                  ],
                )),
                      Expanded(
                        child: Container(
                            height: height,
                            width: width,
                            color: Colors.black,
                            child: allUsers.isEmpty
                                ? Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [Text("no data")],
                                  )
                                : ListView.builder(
                                    itemCount: allUsers.length,
                                    itemBuilder: (context, index) {
                                      return Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Card(
                                          color: Colors.black,
                                          elevation: 7,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15)),
                                          child: Stack(
                                            children: [
                                              Container(
                                                alignment: Alignment.centerLeft,
                                                height: height * 0.17,
                                                width: width,
                                                decoration: BoxDecoration(
                                                    color: Color.fromARGB(
                                                        255, 80, 75, 75),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15),
                                                    border: Border.all(
                                                        color: Colors.white)),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceAround,
                                                  children: [
                                                    Container(
                                                      height: height * 0.03,
                                                      width: width * 0.5,
                                                      decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text("Name : "),
                                                          Text(allUsers[index]
                                                              .fullname!),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      height: height * 0.03,
                                                      width: width * 0.5,
                                                      decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text("Email :  "),
                                                          Text(allUsers[index]
                                                              .email!),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      height: height * 0.03,
                                                      width: width * 0.5,
                                                      decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text("DOB:  "),
                                                          Text(allUsers[index]
                                                              .date!),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      height: height * 0.03,
                                                      width: width * 0.5,
                                                      decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(5)),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text("mobile : "),
                                                          Text(allUsers[index]
                                                              .number!),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsets.only(
                                                  left: width * 0.6,
                                                ),
                                                child: Container(
                                                  height: height * 0.17,
                                                  width: width * 0.3,
                                                  // color: Colors.white,
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceAround,
                                                    children: [
                                                      InkWell(
                                                        onTap: () {
                                                          var reqId = Uuid();
                                                          String id =
                                                              reqId.v4();

                                                          Reqmodel model = Reqmodel(
                                                              reciverid:
                                                                  allUsers[
                                                                          index]
                                                                      .userId,
                                                              recivername:
                                                                  allUsers[
                                                                          index]
                                                                      .fullname,
                                                              requestid: id,
                                                              senderid:
                                                                  StaticData
                                                                      .model!
                                                                      .userId,
                                                              sendername:
                                                                  StaticData
                                                                      .model!
                                                                      .fullname,
                                                              status:
                                                                  "pending");
                                                          FirebaseFirestore
                                                              .instance
                                                              .collection(
                                                                  "requests")
                                                              .doc(id)
                                                              .set(model
                                                                  .toMap());
                                                        },
                                                        child: Container(
                                                            alignment: Alignment
                                                                .center,
                                                            height:
                                                                height * 0.06,
                                                            width: width * 0.3,
                                                            decoration: BoxDecoration(
                                                                color: Colors
                                                                    .amber,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5)),
                                                            child: Text(
                                                                "send request")),
                                                      ),

                                                      InkWell(
                                                        onTap: () {
                                                          FirebaseFirestore
                                                              .instance
                                                              .collection(
                                                                  "users")
                                                              .doc(allUsers[
                                                                      index]
                                                                  .userId)
                                                              .delete()
                                                              .then((value) {
                                                            getUsers();
                                                          });
                                                        },
                                                        child: Container(
                                                            alignment: Alignment
                                                                .center,
                                                            height:
                                                                height * 0.06,
                                                            width: width * 0.3,
                                                            decoration: BoxDecoration(
                                                                color: Colors
                                                                    .amber,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5)),
                                                            child:
                                                                Text("Delete")),
                                                      ), //////////////////////
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  )),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      Container(
                        alignment: Alignment.center,
                        height: height * 0.1,
                        width: width,
                        color: Colors.white,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Icon(
                                Icons.arrow_back,
                                size: 30,
                                color: Colors.black,
                              ),
                            ),
                            Container(
                              alignment: Alignment.centerLeft,
                              height: height * 0.08,
                              width: width * 0.75,
                              // color: Colors.pink,
                              child: Text(
                                "Update Your Data",
                                style: TextStyle(
                                    color: Colors.black, fontSize: 22),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: height,
                          width: width,
                          color: Colors.black,
                          child: Center(
                            child: Container(
                              height: height * 0.75,
                              width: width,
                              color: Colors.black,
                              child:
                                  /////////
                                  Container(
                                height: height * 0.1,
                                width: width * 0.9,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    SizedBox(
                                      height: height * 0.1,
                                    ),
                                    Container(
                                      height: height * 0.07,
                                      width: width * 0.55,
                                      child: TextFormField(
                                        decoration: InputDecoration(
                                            enabledBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(10)),
                                                borderSide: BorderSide(
                                                    color: Colors.grey[400]!)),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(10)),
                                                borderSide: BorderSide(
                                                    color: Colors.grey[400]!)),
                                            filled: true,
                                            fillColor: Colors.grey[100],
                                            hintText: "Update Name"),
                                        controller: updatecontroller,
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        FirebaseFirestore.instance
                                            .collection("users")
                                            .doc(StaticData.model!.userId)
                                            .update({
                                          "full name": updatecontroller.text
                                        });
                                      },
                                      child: Container(
                                          alignment: Alignment.center,
                                          height: height * 0.06,
                                          width: width * 0.3,
                                          decoration: BoxDecoration(
                                              color: Colors.amber,
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          child: Text("Update")),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                 Container(
                      height: height,
                      width: width,
                      color: Colors.blue,
                      
                    ),
                  
                ],
              ),
            ),
            Container(
              height: height * 0.1,
              width: width,
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  InkWell(
                      onTap: () {
                        controller.jumpToPage(0);
                      },
                      child: Icon(Icons.home)),
                  InkWell(
                      onTap: () {
                        controller.jumpToPage(1);
                      },
                      child: Icon(Icons.person)),
                  InkWell(
                      onTap: () {
                        controller.jumpToPage(2);
                      },
                      child: Icon(Icons.settings)),
                  InkWell(
                      onTap: () 
                      
                      {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => sendRequest(),
                          ));
                    },
                     
                      child: Icon(Icons.search)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
