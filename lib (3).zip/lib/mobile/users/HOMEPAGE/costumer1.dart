import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_ecommers/mobile/users/HOMEPAGE/chatHomepage.dart';

class Emily extends StatefulWidget {
  const Emily({Key? key}) : super(key: key);

  @override
  State<Emily> createState() => _EmilyState();
}

class _EmilyState extends State<Emily> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    final commentcontroller = TextEditingController();

    return SafeArea(
      child: Scaffold(
        body: Container(
          alignment: Alignment.topCenter,
          height: height,
          width: width,
          color: Colors.grey[100],
          child: Column(
            children: [
              Container(
                height: height * 0.07,
                width: width,
                // color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                      size: 30,
                    ),
                    Text(
                      "EMILY JOHNSON",
                      style: TextStyle(color: Colors.black, fontSize: 18),
                    ),
                    Icon(
                      Icons.search,
                      color: Colors.black,
                      size: 30,
                    )
                  ],
                ),
              ),
              Container(
                height: height * 0.88,
                width: width,
                color: Colors.grey[200],
                child: ListView(
                  scrollDirection: Axis.vertical,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: height * 0.31,
                            width: width,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10)),
                            child: Column(
                              children: [
                                Container(
                                  height: height * 0.05,
                                  width: width,
                                  decoration: BoxDecoration(
                                      // color: Colors.pink,
                                      borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(10),
                                          topRight: Radius.circular(10))),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.star,
                                        color: Colors.amber,
                                        size: 25,
                                      ),
                                      Text(
                                        "4.95 (5 ",
                                        style: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      )
                                    ],
                                  ),
                                ),
                                Container(
                                  height: height * 0.001,
                                  width: width,
                                  color: Colors.grey,
                                ),
                                Container(
                                  height: height * 0.05,
                                  width: width,
                                  // color: Colors.grey,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Text("Locat"),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        height: height * 0.02,
                                        width: width * 0.7,
                                        decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Container(
                                          height: height * 0.02,
                                          width: width * 0.5,
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                        ),
                                      ),
                                      Text("4."),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: height * 0.05,
                                  width: width,
                                  // color: Colors.grey,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Text("Check"),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        height: height * 0.02,
                                        width: width * 0.7,
                                        decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Container(
                                          height: height * 0.02,
                                          width: width * 0.6,
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                        ),
                                      ),
                                      Text("4."),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: height * 0.05,
                                  width: width,
                                  // color: Colors.grey,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Text("CleanIn."),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        height: height * 0.02,
                                        width: width * 0.7,
                                        decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Container(
                                          height: height * 0.02,
                                          width: width * 0.5,
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                        ),
                                      ),
                                      Text("3."),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: height * 0.05,
                                  width: width,
                                  // color: Colors.grey,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Text("Accur"),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        height: height * 0.02,
                                        width: width * 0.7,
                                        decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Container(
                                          height: height * 0.02,
                                          width: width * 0.8,
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                        ),
                                      ),
                                      Text("5."),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: height * 0.05,
                                  width: width,
                                  // color: Colors.grey,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Text("Value"),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        height: height * 0.02,
                                        width: width * 0.7,
                                        decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Container(
                                          height: height * 0.02,
                                          width: width * 0.3,
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                        ),
                                      ),
                                      Text("5."),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Reviews (5)",
                                style: TextStyle(
                                    color: Colors.black, fontSize: 18),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: height * 0.55,
                            width: width,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Container(
                                  height: height * 0.1,
                                  width: width * 0.8,
                                  // color: Colors.red,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    startChat(),
                                              ));
                                        },
                                        child: Container(
                                          height: height * 0.1,
                                          width: width * 0.15,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              shape: BoxShape.circle,
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/images/pic6.png"),
                                                  fit: BoxFit.contain)),
                                        ),
                                      ),
                                      Container(
                                        height: height * 0.1,
                                        width: width * 0.6,
                                        color: Colors.white,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(
                                              height: height * 0.04,
                                              width: width * 0.74,
                                              // color: Colors.purple,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Text(
                                                    "Seraphina Lockhart",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 16),
                                                  ),
                                                  Text("Aug 17",
                                                      style: TextStyle(
                                                          color: Colors.grey,
                                                          fontSize: 12))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              alignment: Alignment.topLeft,
                                              height: height * 0.04,
                                              width: width * 0.74,
                                              // color: Colors.purple,
                                              child: Text("Travel Vloger",
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 12)),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Column(
                                  children: [
                                    Container(
                                      height: height * 0.1,
                                      width: width * 0.8,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              "Emily Johnson is a lifesaver! Her 24/7 emergency response and burst pipe repair saved the day when we had a plumbing crisis. Quick, efficient, and highly… ",
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 12)),
                                          Text(
                                            "Read More",
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 13,
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                    ),
                                    Container(
                                      height: height * 0.2,
                                      width: width * 0.8,
                                      decoration: BoxDecoration(
                                          color: Colors.orange,
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          image: DecorationImage(
                                              image: AssetImage(
                                                  "assets/images/pic7.png"),
                                              fit: BoxFit.cover)),
                                    ),
                                    Container(
                                      height: height * 0.05,
                                      width: width * 0.8,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            height: height * 0.04,
                                            width: width * 0.12,
                                            // color: Colors.pink,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Icon(
                                                  Icons.thumb_up,
                                                  color: Colors.grey,
                                                  size: 20,
                                                ),
                                                Text(
                                                  "2",
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 12),
                                                )
                                              ],
                                            ),
                                          ),
                                          Container(
                                            height: height * 0.04,
                                            width: width * 0.12,
                                            // color: Colors.pink,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Icon(
                                                  Icons.chat,
                                                  color: Colors.grey,
                                                  size: 20,
                                                ),
                                                Text(
                                                  "17",
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                                Container(
                                  alignment: Alignment.centerLeft,
                                  height: height * 0.07,
                                  width: width * 0.8,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Colors.grey)),
                                  child: Container(
                                    height: height * 0.07,
                                    width: width * 0.45,
                                    // color: Colors.yellow,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        Container(
                                          height: height * 0.1,
                                          width: width * 0.1,
                                          decoration: BoxDecoration(
                                              color: Colors.orange,
                                              shape: BoxShape.circle,
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/images/pic6.png"),
                                                  fit: BoxFit.contain)),
                                        ),
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          height: height * 0.05,
                                          width: width * 0.3,
                                          // color: Colors.red,
                                          child: TextFormField(
                                            controller: commentcontroller,
                                            decoration: InputDecoration(
                                              hintText: 'Add a comment',
                                              border: InputBorder.none,
                                              hintStyle: TextStyle(
                                                  fontSize: 14,
                                                  color: Colors.grey),
                                              labelStyle: TextStyle(
                                                  color: Colors.black),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: height * 0.55,
                            width: width,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Container(
                                  height: height * 0.1,
                                  width: width * 0.8,
                                  // color: Colors.red,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        height: height * 0.1,
                                        width: width * 0.15,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            shape: BoxShape.circle,
                                            image: DecorationImage(
                                                image: AssetImage(
                                                    "assets/images/pic8.png"),
                                                fit: BoxFit.cover)),
                                      ),
                                      Container(
                                        height: height * 0.1,
                                        width: width * 0.6,
                                        color: Colors.white,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(
                                              height: height * 0.04,
                                              width: width * 0.74,
                                              // color: Colors.purple,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Text(
                                                    "James Scott",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 16),
                                                  ),
                                                  Text("Mar 2",
                                                      style: TextStyle(
                                                          color: Colors.grey,
                                                          fontSize: 12))
                                                ],
                                              ),
                                            ),
                                            Container(
                                              alignment: Alignment.topLeft,
                                              height: height * 0.04,
                                              width: width * 0.74,
                                              // color: Colors.purple,
                                              child: Text("Travel Vloger",
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 12)),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Column(
                                  children: [
                                    Container(
                                      height: height * 0.1,
                                      width: width * 0.8,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              "James Scott is a lifesaver! Her 24/7 emergency response and burst pipe repair saved the day when we had a plumbing crisis. Quick, efficient, and highly… ",
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 12)),
                                          Text(
                                            "Read More",
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 13,
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                    ),
                                    Container(
                                      height: height * 0.2,
                                      width: width * 0.8,
                                      decoration: BoxDecoration(
                                          color: Colors.orange,
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          image: DecorationImage(
                                              image: AssetImage(
                                                  "assets/images/pic7.png"),
                                              fit: BoxFit.cover)),
                                    ),
                                    Container(
                                      height: height * 0.05,
                                      width: width * 0.8,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            height: height * 0.04,
                                            width: width * 0.12,
                                            // color: Colors.pink,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Icon(
                                                  Icons.thumb_up,
                                                  color: Colors.grey,
                                                  size: 20,
                                                ),
                                                Text(
                                                  "38",
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 12),
                                                )
                                              ],
                                            ),
                                          ),
                                          Container(
                                            height: height * 0.04,
                                            width: width * 0.12,
                                            // color: Colors.pink,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Icon(
                                                  Icons.chat,
                                                  color: Colors.grey,
                                                  size: 20,
                                                ),
                                                Text(
                                                  "29",
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                                Container(
                                  alignment: Alignment.centerLeft,
                                  height: height * 0.07,
                                  width: width * 0.8,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Colors.grey)),
                                  child: Container(
                                    height: height * 0.07,
                                    width: width * 0.45,
                                    // color: Colors.yellow,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        Container(
                                          height: height * 0.1,
                                          width: width * 0.1,
                                          decoration: BoxDecoration(
                                              color: Colors.orange,
                                              shape: BoxShape.circle,
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/images/pic8.png"),
                                                  fit: BoxFit.cover)),
                                        ),
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          height: height * 0.05,
                                          width: width * 0.3,
                                          // color: Colors.red,
                                          child: TextFormField(
                                            controller: commentcontroller,
                                            decoration: InputDecoration(
                                              hintText: 'Add a comment',
                                              border: InputBorder.none,
                                              hintStyle: TextStyle(
                                                  fontSize: 14,
                                                  color: Colors.grey),
                                              labelStyle: TextStyle(
                                                  color: Colors.black),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ), /////////////
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
