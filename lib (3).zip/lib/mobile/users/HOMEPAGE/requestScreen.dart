import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_ecommers/mobile/users/staticdata.dart';
import 'package:flutter_application_ecommers/models/FriendModel.dart';
import 'package:flutter_application_ecommers/models/reqModel.dart';

import 'package:uuid/uuid.dart';

class sendRequest extends StatefulWidget {
  const sendRequest({super.key});

  @override
  State<sendRequest> createState() => _sendRequestState();
}

class _sendRequestState extends State<sendRequest> {
  List<Reqmodel> allReq = [];
  void getUsers() async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection("requests")
        .where("reciverid", isEqualTo: StaticData.model!.userId)
        .get();

    for (var data in snapshot.docs) {
      Reqmodel model = Reqmodel.fromMap(data.data() as Map<String, dynamic>);
      setState(() {
        allReq.add(model);
      });
    }
    print(allReq.length);
  }

  @override
  void initState() {
    getUsers();
    super.initState();
  }

  var height, width;
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            Container(
                alignment: Alignment.center,
                height: height * 0.1,
                width: width,
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.arrow_back,
                          size: 30,
                        )),
                    Container(
                      alignment: Alignment.centerLeft,
                      height: height * 0.09,
                      width: width * 0.85,
                      child: Text(
                        "All Requests",
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 24),
                      ),
                    ),
                  ],
                )),
            Container(
              height: height! * 0.8,
              width: width,
              color: Colors.black,
              child: ListView.builder(
                itemCount: allReq.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Stack(
                      children: [
                        Card(
                          color: Colors.black,
                          elevation: 7,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          child: Container(
                            height: height! * 0.25,
                            width: width,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    height: height * 0.05,
                                    width: width,
                                 
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text("sender ID: "),
                                        Text(allReq[index].senderid!),
                                      ],
                                    )),
                               Container(
                                alignment: Alignment.centerLeft,
                                    height: height * 0.05,
                                    width: width,
                                   
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text("sender Name: "),
                                        Container(
                                          alignment: Alignment.centerLeft,
                                          height: height*0.09,
                                          width: width*0.65,
                                         
                                          child: Text(allReq[index].sendername!)),
                                      ],
                                    )),
                                Container(
                                    height: height * 0.05,
                                    width: width,
                                   
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        Text("Request id: "),
                                        Text(allReq[index].requestid!),
                                      ],
                                    )),
                                Container(
                                  height: height! * 0.1,
                                  width: width,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          // print(StaticData.model!.userId);
                                          // print(allReq[index].senderid);
                                          var fId = Uuid();
                                          String id = fId.v4();

                                          FriendModel model = FriendModel(
                                              friendname:
                                                  allReq[index].sendername,
                                              friendId: allReq[index].senderid,
                                              userId: StaticData.model!.userId,
                                              id: id);

                                          FirebaseFirestore.instance /////
                                              .collection("Friends")
                                              .doc(id)
                                              .set(model.toMap());

                                          var fId2 = Uuid();
                                          String id2 = fId2.v4();

                                          FriendModel modelf = FriendModel(
                                              friendname:
                                                  StaticData.model!.fullname,
                                              friendId:
                                                  StaticData.model!.userId,
                                              userId: allReq[index].senderid,
                                              id: id2);

                                          FirebaseFirestore.instance /////
                                              .collection("Friends")
                                              .doc(id2)
                                              .set(modelf.toMap());
                                        },
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: height! * 0.05,
                                          width: width! * 0.3,
                                          decoration: BoxDecoration(
                                              color: Colors.amber,
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          child: Text("Accept"),
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        height: height! * 0.05,
                                        width: width! * 0.3,
                                        decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius:
                                                BorderRadius.circular(5)),
                                        child: Text("Reject"),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // child: Icon(
                        //   Icons.add_rounded,
                        //   color: Colors.blue,
                        //   size: 40,
                        // ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
