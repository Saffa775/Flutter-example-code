import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_ecommers/mobile/users/HOMEPAGE/chat_screen.dart';
import 'package:flutter_application_ecommers/mobile/users/HOMEPAGE/requestScreen.dart';
import 'package:flutter_application_ecommers/mobile/users/UserModel.dart';
import 'package:flutter_application_ecommers/mobile/users/staticdata.dart';
import 'package:flutter_application_ecommers/models/FriendModel.dart';
import 'package:flutter_application_ecommers/models/reqModel.dart';


import 'package:uuid/uuid.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  PageController controller = PageController();
  // height = MediaQuery.of(context).size.height;
  // width = MediaQuery.of(context).size.width;
  
  final Firstnamecontroller = TextEditingController();
  final Lastnamecontroller = TextEditingController();
  final emailcontroller = TextEditingController();
  final passwordcontroller = TextEditingController();
  final updatecontroller = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  List<UserModel> allUsers = [];
  void getUsers() async {
    allUsers.clear();
    QuerySnapshot snapshot =
        await FirebaseFirestore.instance.collection("users").get();

    for (var data in snapshot.docs) {
      UserModel model = UserModel.fromMap(data.data() as Map<String, dynamic>);
      setState(() {
        allUsers.add(model);
      });
    }
  }

  List<FriendModel> allfiends = [];
  void getfriend() async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection("Friends")
        .where("userId", isEqualTo: StaticData.model!.userId)
        .get();

    for (var data in snapshot.docs) {
      FriendModel model =
          FriendModel.fromMap(data.data() as Map<String, dynamic>);
      setState(() {
        allfiends.add(model);
      });
    }
  }

  @override
  void initState() {
    getUsers();
    getfriend();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    void initState() {
      getUsers();
      getfriend();

      super.initState();
    }

    String chatRoomId(String user1, String user2) {
      ////////chat room
      if (user1[0].toLowerCase().codeUnits[0] >
          user2.toLowerCase().codeUnits[0]) {
        return "$user1$user2";
      } else {
        return "$user2$user1";
      }
    }
 final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      key: _scaffoldKey,
      drawer: Drawer(
          child: Stack(
        children: [
          Container(
            height: height,
            width: width,
            color: Color.fromRGBO(0, 150, 136, 1),
            child: Padding(
              padding: EdgeInsets.only(top: height * 0.15),
              child: Container(
                height: height * 0.4,
                width: width,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(30),
                        topLeft: Radius.circular(30))),
                child: Column(
                  children: [
                    SizedBox(
                      height: 24,
                    ),
                    Container(
                      height: height * 0.08,
                      width: width,
                      color: Colors.green,
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    Container(
                      height: height * 0.08,
                      width: width,
                      color: Colors.yellow,
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    Container(
                      height: height * 0.08,
                      width: width,
                      color: Colors.teal,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      )),
      body: Column(
        children: [
          Expanded(
            child: PageView(
              controller: controller,
              scrollDirection: Axis.horizontal,
              children: [
                Container(
                  height: height,
                  width: width,
                  color: Colors.white,
                  child: Stack(
                    children: [
                      Center(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          // Container(
                          //   height: height! * 0.1,
                          //   width: width,
                          //   color: Colors.blue,
                          //   child: Row(
                          //     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          //     children: [
                          //       Text(
                          //         "Pixel",
                          //         style: TextStyle(
                          //             color: Colors.white,
                          //             fontSize: 25,
                          //             fontWeight: FontWeight.bold),
                          //       ),
                          //       InkWell(
                          //         onTap: () {
                          //           Navigator.push(
                          //               context,
                          //               MaterialPageRoute(
                          //                 builder: (context) => sendRequest(),
                          //               ));
                          //         },
                          //         child: Icon(
                          //           Icons.search_sharp,
                          //           size: 35,
                          //           color: Colors.white,
                          //         ),
                          //       ),
                          //       Icon(
                          //         Icons.camera_enhance_rounded,
                          //         size: 35,
                          //         color: Colors.white,
                          //       ),
                          //       Icon(
                          //         Icons.more_vert,
                          //         size: 35,
                          //         color: Colors.white,
                          //       )
                          //     ],
                          //   ),
                          // ),
                          // Container(
                          //   height: height! * 0.7,
                          //   width: width,
                          //   child: ListView.builder(
                          //       //////////////chatroom
                          //       itemCount: allfiends.length,
                          //       itemBuilder: (context, index) {
                          //         return Stack(children: [
                          //           InkWell(
                          //             onTap: () {
                          //               String chatid = chatRoomId(
                          //                   StaticData.model!.userId!,
                          //                   allfiends[index].friendId!);
                          //               print(chatid);
                          //               Navigator.push(
                          //                   context,
                          //                   MaterialPageRoute(
                          //                     builder: (context) => ChatScreen(
                          //                         chatroomId: chatid,
                          //                         userModel: allfiends[index],
                          //                         profileModel: StaticData.model!,
                          //                         username:
                          //                             allfiends[index].friendname!, status: 'online',),
                          //                   ));
                          //             },
                          //             child: Card(
                          //               color: Colors.black,
                          //               elevation: 7,
                          //               shape: RoundedRectangleBorder(
                          //                   borderRadius:
                          //                       BorderRadius.circular(20)),
                          //               child: Container(
                          //                 height: height! * 0.1,
                          //                 width: width,
                          //                 decoration: BoxDecoration(
                          //                     color: Colors.white,
                          //                     borderRadius:
                          //                         BorderRadius.circular(15)),
                          //                 child: Column(
                          //                   children: [
                          //                     Row(
                          //                       mainAxisAlignment:
                          //                           MainAxisAlignment.start,
                          //                       children: [
                          //                         Container(
                          //                           alignment: Alignment.center,
                          //                           height: height! * 0.08,
                          //                           width: width! * 0.15,
                          //                           decoration: BoxDecoration(
                          //                               color: Colors.blue,
                          //                               shape: BoxShape.circle),
                          //                           child: Icon(
                          //                             Icons.person,
                          //                             size: 35,
                          //                             color: Colors.white,
                          //                           ),
                          //                         ),
                          //                         Container(
                          //                             height: height! * 0.08,
                          //                             width: width! * 0.5,
                          //                             child: Padding(
                          //                               padding:
                          //                                   const EdgeInsets.all(
                          //                                       8.0),
                          //                               child: Text(
                          //                                 allfiends[index]
                          //                                     .friendname!,
                          //                                 style: TextStyle(
                          //                                   fontSize: 20,
                          //                                 ),
                          //                               ),
                          //                             )),
                          //                       ],
                          //                     )
                          //                   ],
                          //                 ),
                          //               ),
                          //             ),
                          //           ),
                          //         ]);
                          //       }),
                          // ),
                        ],
                      )),
                      Padding(
                        padding: EdgeInsets.only(top: height * 0.15),
                        child: Container(
                          height: height* 0.75,
                          width: width,
                          decoration: BoxDecoration(
                              color: Color.fromARGB(255, 9, 77, 70),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(70),
                                  topRight: Radius.circular(70))),
                          child: Padding(
                            padding: EdgeInsets.only(top: height * 0.11),
                            child: Center(
                              child: Container(
                                height: height* 0.64,
                                width: width,
                                child: ListView.builder(
                                    //////////////chatroom
                                    itemCount: allfiends.length,
                                    itemBuilder: (context, index) {
                                      return Stack(children: [
                                        InkWell(
                                          onTap: () {
                                            String chatid = chatRoomId(
                                                StaticData.model!.userId!,
                                                allfiends[index].friendId!);
                                            print(chatid);
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) =>
                                                      ChatScreen(
                                                    chatroomId: chatid,
                                                    userModel: allfiends[index],
                                                    profileModel:
                                                        StaticData.model!,
                                                    username: allfiends[index]
                                                        .friendname!,
                                                    status: 'online',
                                                  ),
                                                ));
                                          },
                                          child: Center(
                                            child: Container(
                                              alignment: Alignment.centerLeft,
                                              height: height* 0.08,
                                              width: width* 0.97,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          30)),
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        alignment:
                                                            Alignment.center,
                                                        height: height * 0.08,
                                                        width: width * 0.15,
                                                        decoration:
                                                            BoxDecoration(
                                                                color:
                                                                    Colors.blue,
                                                                shape: BoxShape
                                                                    .circle),
                                                        child: Icon(
                                                          Icons.person,
                                                          size: 35,
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                      Container(
                                                        height: height* 0.08,
                                                        width: width * 0.5,
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                          child: Text(
                                                            allfiends[index]
                                                                .friendname!,
                                                            style: TextStyle(
                                                              fontSize: 20,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]);
                                    }),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: height * 0.09, left: width * 0.1),
                        child: InkWell(
                          onTap: () {
                            _scaffoldKey.currentState!
                                .openDrawer(); /////////drawer
                          },
                          child: Icon(
                            Icons.menu,
                            size: 40,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: height * 0.09, left: width * 0.71),
                        child: Text(
                          "Chat",
                          style: TextStyle(
                              fontStyle: FontStyle.italic,
                              fontSize: 40,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: height * 0.2,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: 6,
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => sendRequest(),
                                    ));
                              },
                              child: Container(
                                height: height * 0.06,
                                width: width* 0.8,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(30)),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Icon(Icons.search),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text("Search")
                                  ],
                                ),
                              ),
                            ),
                           
                              
                              Container(
                                alignment: Alignment.center,
                                height: height* 0.07,
                                width: width * 0.15,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle),
                              ),
                            
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: height * 0.8, left: width * 0.76),
                        child: Container(
                          height: height* 0.1,
                          width: width * 0.2,
                          decoration: BoxDecoration(
                              color: Colors.white, shape: BoxShape.circle),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                    height: height,
                    width: width,
                    color: Color.fromARGB(255, 9, 77, 70),
                    child: allUsers.isEmpty
                        ? Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [Text("no data")],
                          )
                        : ListView.builder(
                            itemCount: allUsers.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Card(
                                  color: Colors.black,
                                  elevation: 7,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15)),
                                  child: Stack(
                                    children: [
                                      Container(
                                        height: height* 0.15,
                                        width: width,
                                        decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius:
                                                BorderRadius.circular(15)),
                                        child: Center(
                                          child: Column(
                                            children: [
                                              Text(allUsers[index].email!),
                                              Text(allUsers[index].fullname!),
                                              Text(allUsers[index].date!),
                                                Text(allUsers[index].number!),
                                              
                                              
                                            ],
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            EdgeInsets.only(left: width * 0.67),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            ElevatedButton(
                                                onPressed: () {
                                                  var reqId = Uuid();
                                                  String id = reqId.v4();

                                                  Reqmodel model = Reqmodel(
                                                      reciverid: allUsers[index]
                                                          .userId,
                                                      recivername:
                                                          allUsers[index]
                                                              .fullname,
                                                      requestid: id,
                                                      senderid: StaticData
                                                          .model!.userId,
                                                      sendername: StaticData
                                                          .model!.fullname,
                                                      status: "pending");
                                                  FirebaseFirestore.instance
                                                      .collection("requests")
                                                      .doc(id)
                                                      .set(model.toMap());
                                                },
                                                child: Text("send request")),
                                            ElevatedButton(
                                                onPressed: () {
                                                  FirebaseFirestore.instance
                                                      .collection("users")
                                                      .doc(allUsers[index]
                                                          .userId)
                                                      .delete()
                                                      .then((value) {
                                                    getUsers();
                                                  });
                                                },
                                                child: Text(
                                                    "Delete")), //////////////////////
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          )),
                Container(
                  height: height,
                  width: width,
                  color: Color.fromARGB(255, 9, 77, 70),
                  child: Container(
                    height: height* 0.1,
                    width: width* 0.5,
                    child: Column(
                      children: [
                        SizedBox(
                          height: height * 0.1,
                        ),
                        TextFormField(
                          decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(30)),
                                  borderSide:
                                      BorderSide(color: Colors.grey[400]!)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(30)),
                                  borderSide:
                                      BorderSide(color: Colors.grey[400]!)),
                              filled: true,
                              prefixIcon: Icon(Icons.key),
                              fillColor: Colors.grey[100],
                              hintText: "Enter"),
                          controller: updatecontroller,
                        ),
                        ElevatedButton(
                            onPressed: () {
                              FirebaseFirestore.instance
                                  .collection("users")
                                  .doc(StaticData.model!.userId)
                                  .update({
                                "firstname": updatecontroller.text
                              }); ////yahan kuch ni likhna for delete
                            },
                            child: Text("Update")),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
       
        ],
      ),
    );
  }
}
