// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class UserModel {
   String? fullname;
  String? email;
  String? date;
  String? number;
  String? userId;
  
  UserModel({
    this.fullname,
    this.email,
    this.date,
    this.number,
    this.userId,
  });

  UserModel copyWith({
    String? fullname,
    String? email,
    String? date,
    String? number,
    String? userId,
  }) {
    return UserModel(
      fullname: fullname ?? this.fullname,
      email: email ?? this.email,
      date: date ?? this.date,
      number: number ?? this.number,
      userId: userId ?? this.userId,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'fullname': fullname,
      'email': email,
      'date': date,
      'number': number,
      'userId': userId,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      fullname: map['fullname'] != null ? map['fullname'] as String : null,
      email: map['email'] != null ? map['email'] as String : null,
      date: map['date'] != null ? map['date'] as String : null,
      number: map['number'] != null ? map['number'] as String : null,
      userId: map['userId'] != null ? map['userId'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory UserModel.fromJson(String source) => UserModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'UserModel(fullname: $fullname, email: $email, date: $date, number: $number, userId: $userId)';
  }

  @override
  bool operator ==(covariant UserModel other) {
    if (identical(this, other)) return true;
  
    return 
      other.fullname == fullname &&
      other.email == email &&
      other.date == date &&
      other.number == number &&
      other.userId == userId;
  }

  @override
  int get hashCode {
    return fullname.hashCode ^
      email.hashCode ^
      date.hashCode ^
      number.hashCode ^
      userId.hashCode;
  }
  }
 