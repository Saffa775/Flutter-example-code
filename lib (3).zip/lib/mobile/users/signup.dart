import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_ecommers/mobile/login.dart';
import 'package:flutter_application_ecommers/mobile/users/UserModel.dart';
import 'package:uuid/uuid.dart';

class signupPage extends StatefulWidget {
  const signupPage({Key? key});

  @override
  State<signupPage> createState() => _signupPageState();
}

var height, width;

class _signupPageState extends State<signupPage> {
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    final fullnamecontroller = TextEditingController();
    final emailcontroller = TextEditingController();
    final Datecontroller = TextEditingController();
    final numbercontroller = TextEditingController();

    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Container(
          height: height! * 0.9,
          width: width! * 0.9,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                "assets/images/background.jpg",
              ),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            height: height! * 0.9,
            width: width! * 0.9,
            color: Colors.white.withOpacity(0.8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: height! * 0.8,
                  width: width! * 0.8,
                  // color: Colors.green,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(height: height! * 0.02),
                      Container(
                        alignment: Alignment.topCenter,
                        height: height! * 0.2,
                        width: width! * 0.7,
                        // color: Colors.white,
                        child: Text(
                          "Register",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.italic,
                              fontSize: 35),
                        ),
                      ),
                      // SizedBox(height: height! * 0.02),
                      Container(
                        height: height * 0.07,
                        width: width * 0.8,
                        child: TextFormField(
                          controller: fullnamecontroller,
                          decoration:  InputDecoration(
                              prefixIcon:Icon(Icons.person,color: Colors.black,),
                              hintText: 'Full Name',hintStyle: TextStyle(color: Colors.grey[800]),
                            
                              labelStyle: TextStyle(color: Colors.black),
                              suffixIcon: Icon(
                                Icons.done,
                                color: Colors.black,
                              ),
                              
                              ),
                          validator: (String? value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            }
                            return null;
                          },
                        ),
                      ),

                      // SizedBox(
                      //   height: height! * 0.02,
                      // ),
                   Container(
                        height: height * 0.07,
                        width: width * 0.8,
                        child: TextFormField(
                          
                          controller: emailcontroller,
                          decoration:  InputDecoration(
                          
                              prefixIcon:Icon(Icons.email,color: Colors.black,),
                              hintText: 'Email Address',hintStyle: TextStyle(color: Colors.grey[800]),
                            
                              labelStyle: TextStyle(color: Colors.black),
                              suffixIcon: Icon(
                                Icons.done,
                                color: Colors.black,
                              ),
                              
                              ),
                          validator: (String? value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            }
                            return null;
                          },
                        ),
                      ),
                     Container(
                        height: height * 0.07,
                        width: width * 0.8,
                        child: TextFormField(
                          controller: Datecontroller,
                          decoration:  InputDecoration(
                              prefixIcon:Icon(Icons.calendar_month,color: Colors.black,),
                              hintText: 'Birth Date',hintStyle: TextStyle(color: Colors.grey[800]),
                            
                              labelStyle: TextStyle(color: Colors.black),
                              suffixIcon: Icon(
                                Icons.done,
                                color: Colors.black,
                              ),
                              
                              ),
                          validator: (String? value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            }
                            return null;
                          },
                        ),
                      ),
                        Container(
                        height: height * 0.07,
                        width: width * 0.8,
                        child: TextFormField(
                          controller: numbercontroller,
                          decoration:  InputDecoration(
                              prefixIcon:Icon(Icons.phone,color: Colors.black,),
                              hintText: 'Mobile Number',hintStyle: TextStyle(color: Colors.grey[800]),
                            
                              labelStyle: TextStyle(color: Colors.black),
                              suffixIcon: Icon(
                                Icons.done,
                                color: Colors.black,
                              ),
                              
                              ),
                          validator: (String? value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            }
                            return null;
                          },
                        ),
                      ),

                      //                   CircleAvatar(
                      //   backgroundColor:Color.fromARGB(255, 9, 77, 70),
                      //   child: Icon(
                      //     Icons.keyboard_arrow_right,
                      //     size: 40,
                      //     color: Colors.white,
                      //   ),
                      // ),

                      InkWell(
                        onTap: () {
                          var id = Uuid();
                          String uid = id.v4();
                          UserModel model = UserModel(
                              fullname: fullnamecontroller.text,
                              email: emailcontroller.text,
                              date: Datecontroller.text,
                              number: numbercontroller.text,
                              userId: uid);
                          print(model.toMap());
                          print(uid);
                          FirebaseFirestore.instance
                              .collection("users")
                              .doc(uid)
                              .set(model.toMap());
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: height * 0.07,
                          width: width * 0.7,
                          decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(20)),
                          child: Text(
                            "Register",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => UserLoginPage(),
                              ));
                        },
                        child: Text(
                          "Registered Already?Login",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
