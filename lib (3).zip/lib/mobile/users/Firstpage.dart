import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_ecommers/mobile/login.dart';
import 'package:flutter_application_ecommers/mobile/users/signup.dart';
import 'package:get/get.dart';

class Firstclass extends StatefulWidget {
  const Firstclass({Key? key}) : super(key: key);

  @override
  State<Firstclass> createState() => _FirstclassState();
}

class _FirstclassState extends State<Firstclass> {
  var height, width;
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Container(
        height: height,
        width: width,
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              height: height * 0.47,
              width: width,
              // color: Colors.green,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: height * 0.35,
                    width: width * 0.7,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        // color: Colors.red,
                        image: DecorationImage(
                          image: AssetImage(
                            "assets/images/firstpage.png",
                          ),
                        )),
                  )
                ],
              ),
            ),
            Container(
              height: height * 0.32,
              width: width,
              // color: Colors.amber,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: height * 0.08,
                    width: width * 0.6,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text("''Building Dreams, Breaking"),
                        Text("Barriers: Women in Construction''")
                      ],
                    ),
                  ),
                  Text(
                    "Build, Connect & Construct with Your Crew!",
                    style: TextStyle(fontSize: 10),
                  ),
                  Container(
                    height: height * 0.03,
                    width: width * 0.2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Icon(
                          Icons.circle_outlined,
                          size: 15,
                        ),
                        Icon(
                          Icons.circle_outlined,
                          size: 15,
                        ),
                        Icon(
                          Icons.circle,
                          size: 15,
                          color: Colors.black,
                        ),
                        Icon(
                          Icons.circle_outlined,
                          size: 15,
                        )
                      ],
                    ),
                  ),
                  InkWell(
                     onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => signupPage(),
                            ));
                      },
                    child: Container(
                      alignment: Alignment.center,
                      height: height * 0.07,
                      width: width * 0.7,
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(20)),
                     
                       
                        child: Text(
                          "Continue",
                          style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.bold),
                        ),
                      
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
