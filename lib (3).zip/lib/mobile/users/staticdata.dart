import 'package:flutter_application_ecommers/mobile/users/UserModel.dart';

class StaticData{

static UserModel? model;


}