import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_ecommers/mobile/users/HOMEPAGE/Homepage.dart';
import 'package:flutter_application_ecommers/mobile/users/UserModel.dart';
import 'package:flutter_application_ecommers/passwords/forgetpassword.dart';
import 'package:flutter_application_ecommers/mobile/users/signup.dart';
import 'package:flutter_application_ecommers/mobile/users/staticdata.dart';
import 'package:get/get.dart';

class UserLoginPage extends StatefulWidget {
  const UserLoginPage({Key?key});

  @override
  State<UserLoginPage> createState() => _UserLoginPageState();
}

class _UserLoginPageState extends State<UserLoginPage> {

  
var height, width;
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
   
    final emailcontroller = TextEditingController();
    final fullnamecontroller = TextEditingController();

    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Container(
          height: height! * 0.9,
          width: width! * 0.9,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                "assets/images/background.jpg",
              ),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            height: height! * 0.9,
            width: width! * 0.9,
            color: Colors.white.withOpacity(0.8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: height! * 0.8,
                  width: width! * 0.8,
                  // color: Colors.green,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(height: height! * 0.02),
                      Container(
                        alignment: Alignment.topCenter,
                        height: height! * 0.25,
                        width: width! * 0.7,
                        // color: Colors.white,
                        child: Text(
                          "Login",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.italic,
                              fontSize: 30),
                        ),
                      ),
                      // SizedBox(height: height! * 0.02),
                       Container(
                        height: height * 0.07,
                        width: width * 0.8,
                        child: TextFormField(
                          controller: fullnamecontroller,
                          decoration:  InputDecoration(
                              prefixIcon:Icon(Icons.person,color: Colors.black,),
                              hintText: 'User Name',
                            
                              labelStyle: TextStyle(color: Colors.black),
                              suffixIcon: Icon(
                                Icons.done,
                                color: Colors.black,
                              ),
                              
                              ),
                          validator: (String? value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            }
                            return null;
                          },
                        ),
                      ),
                      // SizedBox(
                      //   height: height! * 0.02,
                      // ),
                    Container(
                        height: height * 0.07,
                        width: width * 0.8,
                        child: TextFormField(
                          controller: emailcontroller,
                          decoration:  InputDecoration(
                              prefixIcon:Icon(Icons.email,color: Colors.black,),
                              hintText: 'Email',
                            
                              labelStyle: TextStyle(color: Colors.black),
                              suffixIcon: Icon(
                                Icons.done,
                                color: Colors.black,
                              ),
                              
                              ),
                          validator: (String? value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            }
                            return null;
                          },
                        ),
                      ),
                      InkWell(
                        onTap: () async {
                          QuerySnapshot Snapshot = await FirebaseFirestore
                              .instance
                              .collection("users")
                              .where("fullname", isEqualTo: fullnamecontroller.text)
                              .where("email",
                                  isEqualTo: emailcontroller.text)
                              .get();
                          if (Snapshot.docs.isEmpty) {
                            print("Invalid email or username");
                          } else {
                            UserModel model = UserModel.fromMap(Snapshot.docs[0]
                                .data() as Map<String, dynamic>);
                            print("Login Succesfull");
                            print(model.toString());
                            StaticData.model = model; //////today
                            Navigator.push(       
                                context,
                                MaterialPageRoute(
                                  builder: (context) => Dashboard(),
                                ));
                          }
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: height! * 0.07,
                          width: width! * 0.7,
                          decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(20)),
                          child: Text(
                            "Login",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      //                   CircleAvatar(
                      //   backgroundColor:Color.fromARGB(255, 9, 77, 70),
                      //   child: Icon(
                      //     Icons.keyboard_arrow_right,
                      //     size: 40,
                      //     color: Colors.white,
                      //   ),
                      // ),
                      InkWell(
                         onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => recreatePassword(),
                              ));
                        },
                        
                        child: Text(
                          "Forget Password?",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => signupPage(),
                              ));
                        },
                        child: Text(
                          "Register",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
