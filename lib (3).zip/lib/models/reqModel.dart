// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class Reqmodel {
String? sendername;
String? senderid;
String? recivername;
String? reciverid;
String? status;
String? requestid;
  Reqmodel({
    this.sendername,
    this.senderid,
    this.recivername,
    this.reciverid,
    this.status,
    this.requestid,
  });

  Reqmodel copyWith({
    String? sendername,
    String? senderid,
    String? recivername,
    String? reciverid,
    String? status,
    String? requestid,
  }) {
    return Reqmodel(
      sendername: sendername ?? this.sendername,
      senderid: senderid ?? this.senderid,
      recivername: recivername ?? this.recivername,
      reciverid: reciverid ?? this.reciverid,
      status: status ?? this.status,
      requestid: requestid ?? this.requestid,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'sendername': sendername,
      'senderid': senderid,
      'recivername': recivername,
      'reciverid': reciverid,
      'status': status,
      'requestid': requestid,
    };
  }

  factory Reqmodel.fromMap(Map<String, dynamic> map) {
    return Reqmodel(
      sendername: map['sendername'] != null ? map['sendername'] as String : null,
      senderid: map['senderid'] != null ? map['senderid'] as String : null,
      recivername: map['recivername'] != null ? map['recivername'] as String : null,
      reciverid: map['reciverid'] != null ? map['reciverid'] as String : null,
      status: map['status'] != null ? map['status'] as String : null,
      requestid: map['requestid'] != null ? map['requestid'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory Reqmodel.fromJson(String source) => Reqmodel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'Reqmodel(sendername: $sendername, senderid: $senderid, recivername: $recivername, reciverid: $reciverid, status: $status, requestid: $requestid)';
  }

  @override
  bool operator ==(covariant Reqmodel other) {
    if (identical(this, other)) return true;
  
    return 
      other.sendername == sendername &&
      other.senderid == senderid &&
      other.recivername == recivername &&
      other.reciverid == reciverid &&
      other.status == status &&
      other.requestid == requestid;
  }

  @override
  int get hashCode {
    return sendername.hashCode ^
      senderid.hashCode ^
      recivername.hashCode ^
      reciverid.hashCode ^
      status.hashCode ^
      requestid.hashCode;
  }
}

