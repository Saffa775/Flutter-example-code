import 'package:flutter/material.dart';
import 'package:flutter_application_ecommers/mobile/login.dart';
import 'package:flutter_application_ecommers/mobile/users/Firstpage.dart';
import 'package:flutter_application_ecommers/responsive.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key?key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  void movePage() {
    Future.delayed(Duration(seconds: 3),(){
 Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => Responsive.isMobile(context)
              ? const Firstclass()
              : const SplashScreen()),
    );
    });
   
  }
  @override
  void initState() {
  movePage();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red,
    );
  }
}
