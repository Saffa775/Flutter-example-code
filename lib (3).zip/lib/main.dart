import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:flutter_application_ecommers/splash.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
 
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDSCdcIdWvrhpMztv8AifI8VBhwWRkRvKk",
            authDomain: "ecommers-817e9.firebaseapp.com",
            projectId: "ecommers-817e9",
            storageBucket: "ecommers-817e9.appspot.com",
            messagingSenderId: "315220721267",
            appId: "1:315220721267:web:69c0b78d3270ee26abb406"));
  } else {
    await Firebase.initializeApp();
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key?key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const SplashScreen(),
    );
  }
}
