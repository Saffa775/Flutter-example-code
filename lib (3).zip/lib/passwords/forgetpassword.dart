import 'package:email_otp/email_otp.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_ecommers/passwords/resetpassword.dart';
import 'package:get/get.dart';

class recreatePassword extends StatefulWidget {
  const recreatePassword({Key? key}) : super(key: key);

  @override
  State<recreatePassword> createState() => _recreatePasswordState();
}

class _recreatePasswordState extends State<recreatePassword> {
  TextEditingController email = new TextEditingController();
  TextEditingController otp = new TextEditingController();
  EmailOTP myauth = EmailOTP();
  var height, width;
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Container(
            height: height,
            width: width,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.8),
              image: DecorationImage(
                image: AssetImage(
                  "assets/images/background.jpg",
                ),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              
              height: height*0.9,
              width: width,
              color: Colors.white.withOpacity(0.6),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                     Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                       children: [
                        
                         InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                           child: Container(
                            alignment: Alignment.center,
                             height: height*0.05,
                                               width: width*0.2,
                                             
                            child: Icon(Icons.arrow_back,size: 35,)),
                         ),
                       ],
                     ),
                    Container(
                      height: height*0.9,
                      width: width,
                      // color: Colors.orange,
                      child: Column(
                        
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                         
                          Text(
                            "Forget Password",
                            style: TextStyle(color: Colors.black, fontSize: 27,fontWeight: FontWeight.bold),
                          ),
                          Container(
                            height: height * 0.4,
                            width: width * 0.9,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Card(
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          height: height * 0.07,
                                          width: width * 0.8,
                                          child: TextFormField(
                                            controller: email,
                                            decoration: InputDecoration(
                                        hintText:'User Email',
                                              labelStyle:
                                                  TextStyle(color: Colors.black),
                                            ),
                                            validator: (String? value) {
                                              if (value!.isEmpty) {
                                                return 'Please enter some text';
                                              }
                                              return null;
                                            },
                                          ),
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () async {
                                          myauth.setConfig(
                                              appEmail: "me@saffabakhsh.com",
                                              appName: "Email OTP",
                                              userEmail: email.text,
                                              otpLength: 6,
                                              otpType: OTPType.digitsOnly);
                                          if (await myauth.sendOTP() == true) {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(const SnackBar(
                                              content: Text("OTP has been sent"),
                                            ));
                                          } else {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(const SnackBar(
                                              content: Text("Oops, OTP send failed"),
                                            ));
                                          }
                                        },
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: height * 0.06,
                                          width: width * 0.27,
                                          decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadiusDirectional.circular(5)),
                                          child: Text(
                                            "Send OTP",
                                            style: TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Card(
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          height: height * 0.07,
                                          width: width * 0.8,
                                          child: TextFormField(
                                            controller: otp,
                                            decoration: InputDecoration(
                                              hintText: 'Enter OTP',
                                              labelStyle:
                                                  TextStyle(color: Colors.black),
                                            ),
                                            validator: (String? value) {
                                              if (value!.isEmpty) {
                                                return 'Please enter some text';
                                              }
                                              return null;
                                            },
                                          ),
                                        ),
                                      ),
    
                                      InkWell(
                                        onTap: () async {
                                          if (await myauth.verifyOTP(otp: otp.text) ==
                                              true) {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(const SnackBar(
                                              content: Text("OTP is verified"),
                                            ));
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) => resetPassword(),
                                                ));
                                          } else {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(const SnackBar(
                                              content: Text("Invalid OTP"),
                                            ));
                                          }
                                        },
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: height * 0.06,
                                          width: width * 0.27,
                                          decoration: BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                                  BorderRadiusDirectional.circular(5)),
                                          child: Text(
                                            "Verify OTP",
                                            style: TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      )
                                      // ElevatedButton(
                                      //     onPressed: () async {
                                      //       if (await myauth.verifyOTP(otp: otp.text) ==
                                      //           true) {
                                      //         ScaffoldMessenger.of(context)
                                      //             .showSnackBar(const SnackBar(
                                      //           content: Text("OTP is verified"),
                                      //         ));
                                      //       } else {
                                      //         ScaffoldMessenger.of(context)
                                      //             .showSnackBar(const SnackBar(
                                      //           content: Text("Invalid OTP"),
                                      //         ));
                                      //       }
                                      //     },
                                      //     child: const Text("Verify")),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
