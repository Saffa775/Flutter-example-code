import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_ecommers/mobile/users/UserModel.dart';
import 'package:flutter_application_ecommers/mobile/users/staticdata.dart';

class resetPassword extends StatefulWidget {
  const resetPassword({Key? key}) : super(key: key);

  @override
  State<resetPassword> createState() => _resetPasswordState();
}

var height, width;

class _resetPasswordState extends State<resetPassword> {

  final newpasswordcontroller = TextEditingController();
  final confirmpasswordcontroller = TextEditingController();
  final updatecontroller = TextEditingController();
   final emailcontrolller = TextEditingController();
    final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  List<UserModel> allUsers = [];
  void getUsers() async {
    allUsers.clear();
    QuerySnapshot snapshot =
        await FirebaseFirestore.instance.collection("users").get();

    for (var data in snapshot.docs) {
      UserModel model = UserModel.fromMap(data.data() as Map<String, dynamic>);
      setState(() {
        allUsers.add(model);
      });
    }
  }

  @override
  void initState() {
    getUsers();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
      final height = MediaQuery.of(context).size.height;
   final width = MediaQuery.of(context).size.width;
    void initState() {
      getUsers();

      super.initState();
    }

    return SafeArea(
      child: Scaffold(
        body: Container(
            height: height,
            width: width,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(
                  "assets/images/background.jpg",
                ),
                fit: BoxFit.cover,
              ),
            ),
            child: Center(
              child: Container(
                height: height,
                width: width,
                color: Colors.white.withOpacity(0.6),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Container(
                            alignment: Alignment.center,
                            height: height * 0.05,
                            width: width * 0.2,
                            child: Icon(
                              Icons.arrow_back,
                              size: 35,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      height: height * 0.8,
                      width: width,
                      // color: Colors.pink,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              "Change Password",
                              style:
                                  TextStyle(color: Colors.black, fontSize: 27),
                            ),
                            Container(
                              height: height * 0.3,
                              width: width * 0.7,
                              // color: Colors.green,
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Container(
                                    height: height * 0.07,
                                    width: width * 0.8,
                                    child: TextFormField(
                                      controller: newpasswordcontroller,
                                      decoration: InputDecoration(
                                        hintText: 'New Password',
                                        labelStyle:
                                            TextStyle(color: Colors.black),
                                        suffixIcon: Icon(
                                          Icons.visibility_off,
                                          color: Colors.black,
                                        ),
                                      ),
                                      validator: (String? value) {
                                        if (value!.isEmpty) {
                                          return 'Please enter some text';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  Container(
                                    height: height * 0.07,
                                    width: width * 0.8,
                                    child: TextFormField(
                                      controller: confirmpasswordcontroller,
                                      decoration: InputDecoration(
                                        hintText: 'Confirm Password',
                                        labelStyle:
                                            TextStyle(color: Colors.black),
                                        suffixIcon: Icon(
                                          Icons.visibility_off,
                                          color: Colors.black,
                                        ),
                                      ),
                                      validator: (String? value) {
                                        if (value!.isEmpty) {
                                          return 'Please enter some text';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      FirebaseFirestore.instance
                                          .collection("users")
                                          .doc(StaticData.model!.userId)
                                          .update({
                                        "email": confirmpasswordcontroller.text
                                      }); 
                                    },
                                    child: Container(
                                      alignment: Alignment.center,
                                      height: height * 0.07,
                                      width: width * 0.7,
                                      decoration: BoxDecoration(
                                          color: Colors.black,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: Text(
                                        "Change",
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            )),
      ),
    );
  }
}
